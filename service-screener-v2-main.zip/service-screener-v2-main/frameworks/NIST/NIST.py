import json

import constants as _C
from frameworks.Framework import Framework

class NIST(Framework):
    def __init__(self, data):
        super().__init__(data)
        pass