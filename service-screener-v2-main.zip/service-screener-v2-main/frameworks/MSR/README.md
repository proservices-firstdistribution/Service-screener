1. Original Framework Creator: Pankaj Miglani
1. Framework Co-owner: Rishi Singla
1. Maintainer: KuetTai


Sample Execution
```
screener --regions ALL --frameworks MSR,WAFS,SSB,FTR --others F-SMP-CASH-c3f4544014a0-b9d1877f2a62
```