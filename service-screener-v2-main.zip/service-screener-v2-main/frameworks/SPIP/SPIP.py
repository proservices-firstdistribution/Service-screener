import json

import constants as _C
from frameworks.Framework import Framework

class SPIP(Framework):
    def __init__(self, data):
        super().__init__(data)
        pass