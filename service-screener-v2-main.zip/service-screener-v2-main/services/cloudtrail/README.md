1. Author: KuetTai 
2. Reviewer: HoonSin