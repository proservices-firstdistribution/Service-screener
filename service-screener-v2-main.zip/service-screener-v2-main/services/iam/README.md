1. Original Author: KuetTai
2. PHP to Python Convertor: KuetTai
3. Reviewer: HoonSin